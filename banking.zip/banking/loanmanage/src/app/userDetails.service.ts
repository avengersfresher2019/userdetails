import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {
  //baseUrl="http://localhost:8081/loanmgmt_reject";

  constructor(private http: HttpClient,private service:UserDetailsService) { }
   
  getAll(): Observable<any> {
    return this.http.get('http://localhost:8081/');
  }

  save(Loanmgmt: any): Observable<any> {
    let result: Observable<Object>;
      result = this.http.post('http://localhost:8081/loanmgmt_add/', Loanmgmt);
    return result;
  }

  delete(id: any): Observable<any>{
    return this.http.delete('http://localhost:8081/delete/'+`${id}`, {responseType:'text'});
  }

}
