
import { Component, OnInit } from '@angular/core';
import { UserDetailsService } from '../userDetails.service';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './userDetails.component.html',
  styleUrls: ['./userDetails.component.css']
})
export class UserDetailsComponent implements OnInit {
  Loan: any = {};
  Loanmgmt: Array<any>;
  constructor(private Service: UserDetailsService) { }

  ngOnInit() {
    this.Service.getAll().subscribe(data => {
      this.Loanmgmt = data;
    });
  }
  
  save(form: NgForm) {
    this.Service.save(form).subscribe(result => {
    });
  }
}
