export class UserDetails
{
    id:number;
    Name:String;
    Mobileno:number;
    Emailid:String
    Salary:number;
    CurrentEmi:number;
    CibilScore:number;
    Loantype:String;
    Amountrequired:number;
    ResidenceType:string;
    AddressProof:String;
    Pincode:number;
}