import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserDetailsGetComponent } from './user-details-get.component';

describe('UserDetailsGetComponent', () => {
  let component: UserDetailsGetComponent;
  let fixture: ComponentFixture<UserDetailsGetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserDetailsGetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDetailsGetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
