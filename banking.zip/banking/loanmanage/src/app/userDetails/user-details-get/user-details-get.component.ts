import { Component, OnInit } from '@angular/core';
import { UserDetailsService } from 'src/app/userDetails.service';
import { ActivatedRoute } from '@angular/router';
import { UserDetails } from '../userDetails';

@Component({
  selector: 'app-user-details-get',
  templateUrl: './user-details-get.component.html',
  styleUrls: ['./user-details-get.component.css']
})

export class UserDetailsGetComponent implements OnInit {
  users:UserDetails[]=[];
  user:UserDetails;
  selectedUser:UserDetails;
  id:number;

  constructor(private route:ActivatedRoute,private service:UserDetailsService) { 
  }
  
  ngOnInit() {
    this.service.getAll()
    .subscribe(userDetailsList => {
      this.users = userDetailsList;
      console.dir(this.users);
    });
  }

  onSelection(user:UserDetails){
    console.log("Called onselection");
    this.selectedUser=user;
  }

  deleteLoan(id: any){
    this.service.delete(id)
    .subscribe(data=>{
      console.log(data),error=>console.log(error);
    });
  }
}
