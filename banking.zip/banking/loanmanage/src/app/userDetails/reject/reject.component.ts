import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserDetailsService } from 'src/app/userDetails.service';

@Component({
  selector: 'app-reject',
  templateUrl: './reject.component.html',
  styleUrls: ['./reject.component.css']
})
export class RejectComponent implements OnInit {
  
  id:any;
  
  constructor(private route:ActivatedRoute,private service:UserDetailsService) { }

  ngOnInit() {
    let id=+this.route.snapshot.paramMap.get("id");
  }

    deleteLoan(loanId: any){
      this.service.delete(loanId);
    }
  }
  

  // export class PizzaDeleteComponent implements OnInit {
  //   pizzaId:any;
  //   constructor(private route:ActivatedRoute, private pizzaService:PizzaService) { }
  
  //   ngOnInit() {
  //     let pizzaId=+this.route.snapshot.paramMap.get("pizzaId");
  //     this.deletePizza(pizzaId);
  //   }
  //   deletePizza(pizzaId)
  //   {
  //     this.pizzaService.deletePizza(pizzaId);
  //   }
  // }
