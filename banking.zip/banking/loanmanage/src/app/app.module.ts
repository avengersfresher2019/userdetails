import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { UserDetailsComponent } from './userDetails/userDetails.component';
import { UserDetailsGetComponent } from './userdetails/user-details-get/user-details-get.component';
import { RejectComponent } from './userDetails/reject/reject.component';


@NgModule({
  declarations: [
    AppComponent,
    UserDetailsComponent,
    UserDetailsGetComponent,
    RejectComponent,
   
   

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
