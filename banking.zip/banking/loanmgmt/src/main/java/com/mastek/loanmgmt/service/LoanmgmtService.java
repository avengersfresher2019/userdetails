package com.mastek.loanmgmt.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.mastek.loanmgmt.model.Loanmgmt;
import com.mastek.loanmgmt.repository.ILoanmgmtRepository;

@Service
public class LoanmgmtService {
	
	@Autowired(required=true)
	ILoanmgmtRepository loanmgmtRepository;
	
	 public	Iterable<Loanmgmt> findAll()
		{
			return loanmgmtRepository.findAll();
			
		}
//	 public Loanmgmt findById(int id) {
//			return loanmgmtRepository.findById(id).get();
//		}
		
	 public String save(Loanmgmt entity) {
		 Loanmgmt newloanmgmt =loanmgmtRepository.save(entity);
			return "Added " +newloanmgmt;
		}
	 
	 public String deleteById(int id) {
//		 System.out.println("id ----> "+id);
		 loanmgmtRepository.deleteById(id);
		 
		 return "deleted";
	}
}