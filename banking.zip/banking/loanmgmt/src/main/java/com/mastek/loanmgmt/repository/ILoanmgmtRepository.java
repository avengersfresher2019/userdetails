package com.mastek.loanmgmt.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mastek.loanmgmt.model.Loanmgmt;

@Repository
public interface ILoanmgmtRepository extends CrudRepository<Loanmgmt, Integer> {

}
