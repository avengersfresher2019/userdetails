package com.mastek.loanmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanmgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanmgmtApplication.class, args);
	}

}
