package com.mastek.loanmgmt.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="loanmgmt")
public class Loanmgmt {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String name;
	private String mobileno;
	private String emailid;
	private String gender;
	private double salary;
	private int currentEmi;
	private int cibilscore;
	private double amountrequired;
	private String residencetype;
	private String Addressproof;
	private int pincode;
	public Loanmgmt() {
		super();
		
	}
	public Loanmgmt(int id, String name, String mobileno, String emailid, String gender, double salary, int currentEmi,
			int cibilscore, double amountrequired, String residencetype, String addressproof, int pincode) {
		super();
		this.id = id;
		this.name = name;
		this.mobileno = mobileno;
		this.emailid = emailid;
		this.gender = gender;
		this.salary = salary;
		this.currentEmi = currentEmi;
		this.cibilscore = cibilscore;
		this.amountrequired = amountrequired;
		this.residencetype = residencetype;
		Addressproof = addressproof;
		this.pincode = pincode;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getCurrentEmi() {
		return currentEmi;
	}
	public void setCurrentEmi(int currentEmi) {
		this.currentEmi = currentEmi;
	}
	public int getCibilscore() {
		return cibilscore;
	}
	public void setCibilscore(int cibilscore) {
		this.cibilscore = cibilscore;
	}
	public double getAmountrequired() {
		return amountrequired;
	}
	public void setAmountrequired(double amountrequired) {
		this.amountrequired = amountrequired;
	}
	public String getResidencetype() {
		return residencetype;
	}
	public void setResidencetype(String residencetype) {
		this.residencetype = residencetype;
	}
	public String getAddressproof() {
		return Addressproof;
	}
	public void setAddressproof(String addressproof) {
		Addressproof = addressproof;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Loanmgmt other = (Loanmgmt) obj;
		if (id != other.id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Loanmgmt [id=" + id + ", name=" + name + ", mobileno=" + mobileno + ", emailid=" + emailid + ", gender="
				+ gender + ", salary=" + salary + ", currentEmi=" + currentEmi + ", cibilscore=" + cibilscore
				+ ", amountrequired=" + amountrequired + ", residencetype=" + residencetype + ", Addressproof="
				+ Addressproof + ", pincode=" + pincode + "]";
	}
	
}
