package com.mastek.loanmgmt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mastek.loanmgmt.model.Loanmgmt;
import com.mastek.loanmgmt.service.LoanmgmtService;

@RestController
@CrossOrigin("http://localhost:4200/")
public class LoanmgmtController {
	
	@Autowired(required=true)
	LoanmgmtService loanmgmtService;
	
//	@GetMapping("/loanmgmt/{id}")
//	public Loanmgmt findById(@PathVariable int id) {
//		return loanmgmtService.findById(id);
//	}
	
	@GetMapping(path="/" ,produces="application/json")
	public Iterable<Loanmgmt> findAll(){
		return loanmgmtService.findAll();
		
	}
	    	
	@PostMapping(path="/loanmgmt_add",produces="application/json")
	public String save(@RequestBody Loanmgmt entity) {
		return loanmgmtService.save(entity);
	}
	
	@DeleteMapping(path="/delete/{id}")
	public String deleteById(@PathVariable int id) {
//		System.out.println("deleteById ==> "+id);
		return loanmgmtService.deleteById(id);
	}
//	@DeleteMapping("/delete/{id}")
//	public ResponseEntity<String> deleteAdmin(@PathVariable("id") String id) {
//		loanmgmtService.deleteById(Integer.parseInt(id));
//		return new ResponseEntity<>("Customer has been deleted "+id+"!", HttpStatus.OK);
//	}
}
